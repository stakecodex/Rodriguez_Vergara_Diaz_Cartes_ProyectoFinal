﻿namespace LENTE_2
{
    partial class FormCotizar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtEsferaOD = new TextBox();
            txtCilindroOD = new TextBox();
            btnCalcular = new Button();
            lblResultado = new Label();
            label3 = new Label();
            label4 = new Label();
            btnSiguiente = new Button();
            label6 = new Label();
            txtEjeOD = new TextBox();
            txtEsferaOI = new TextBox();
            txtCilindroOI = new TextBox();
            txtEjeOI = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            txtAdd = new TextBox();
            label13 = new Label();
            txtDP = new TextBox();
            btncancelar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(63, 2);
            label1.Name = "label1";
            label1.Size = new Size(674, 62);
            label1.TabIndex = 1;
            label1.Text = "Sistema de Gestión de Ópticas";
            // 
            // label2
            // 
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 73);
            label2.Name = "label2";
            label2.Size = new Size(776, 480);
            label2.TabIndex = 2;
            label2.Text = "Cotizar Receta";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtEsferaOD
            // 
            txtEsferaOD.Location = new Point(221, 177);
            txtEsferaOD.Name = "txtEsferaOD";
            txtEsferaOD.Size = new Size(125, 27);
            txtEsferaOD.TabIndex = 3;
            // 
            // txtCilindroOD
            // 
            txtCilindroOD.Location = new Point(221, 210);
            txtCilindroOD.Name = "txtCilindroOD";
            txtCilindroOD.Size = new Size(125, 27);
            txtCilindroOD.TabIndex = 4;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(93, 361);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(125, 39);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "Calcular Rango";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblResultado
            // 
            lblResultado.BackColor = SystemColors.ButtonFace;
            lblResultado.Location = new Point(224, 361);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(197, 64);
            lblResultado.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(125, 177);
            label3.Name = "label3";
            label3.Size = new Size(93, 20);
            label3.TabIndex = 7;
            label3.Text = "Esfera (SPH):";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(116, 210);
            label4.Name = "label4";
            label4.Size = new Size(102, 20);
            label4.TabIndex = 8;
            label4.Text = "Cilindro (CYL):";
            // 
            // btnSiguiente
            // 
            btnSiguiente.Location = new Point(427, 361);
            btnSiguiente.Name = "btnSiguiente";
            btnSiguiente.Size = new Size(106, 39);
            btnSiguiente.TabIndex = 10;
            btnSiguiente.Text = "Continuar";
            btnSiguiente.UseVisualStyleBackColor = true;
            btnSiguiente.Click += btnSiguiente_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(113, 270);
            label6.Name = "label6";
            label6.Size = new Size(105, 20);
            label6.TabIndex = 11;
            label6.Text = "EJE (0° - 180°):";
            // 
            // txtEjeOD
            // 
            txtEjeOD.Location = new Point(221, 267);
            txtEjeOD.Name = "txtEjeOD";
            txtEjeOD.Size = new Size(125, 27);
            txtEjeOD.TabIndex = 12;
            // 
            // txtEsferaOI
            // 
            txtEsferaOI.Location = new Point(534, 174);
            txtEsferaOI.Name = "txtEsferaOI";
            txtEsferaOI.Size = new Size(125, 27);
            txtEsferaOI.TabIndex = 13;
            // 
            // txtCilindroOI
            // 
            txtCilindroOI.Location = new Point(534, 210);
            txtCilindroOI.Name = "txtCilindroOI";
            txtCilindroOI.Size = new Size(125, 27);
            txtCilindroOI.TabIndex = 14;
            // 
            // txtEjeOI
            // 
            txtEjeOI.Location = new Point(534, 267);
            txtEjeOI.Name = "txtEjeOI";
            txtEjeOI.Size = new Size(125, 27);
            txtEjeOI.TabIndex = 15;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(413, 270);
            label7.Name = "label7";
            label7.Size = new Size(105, 20);
            label7.TabIndex = 16;
            label7.Text = "EJE (0° - 180°):";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(413, 210);
            label8.Name = "label8";
            label8.Size = new Size(102, 20);
            label8.TabIndex = 17;
            label8.Text = "Cilindro (CYL):";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.ButtonHighlight;
            label9.Location = new Point(422, 177);
            label9.Name = "label9";
            label9.Size = new Size(93, 20);
            label9.TabIndex = 18;
            label9.Text = "Esfera (SPH):";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = SystemColors.ButtonHighlight;
            label10.Location = new Point(183, 120);
            label10.Name = "label10";
            label10.Size = new Size(93, 20);
            label10.TabIndex = 19;
            label10.Text = "Ojo Derecho";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = SystemColors.ButtonHighlight;
            label11.Location = new Point(498, 120);
            label11.Name = "label11";
            label11.Size = new Size(100, 20);
            label11.TabIndex = 20;
            label11.Text = "Ojo Izquierdo";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = SystemColors.ButtonHighlight;
            label12.Location = new Point(174, 309);
            label12.Name = "label12";
            label12.Size = new Size(44, 20);
            label12.TabIndex = 21;
            label12.Text = "ADD:";
            // 
            // txtAdd
            // 
            txtAdd.Location = new Point(221, 306);
            txtAdd.Name = "txtAdd";
            txtAdd.Size = new Size(125, 27);
            txtAdd.TabIndex = 22;
            txtAdd.TextChanged += txtAdd_TextChanged;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = SystemColors.ButtonHighlight;
            label13.Location = new Point(484, 309);
            label13.Name = "label13";
            label13.Size = new Size(31, 20);
            label13.TabIndex = 23;
            label13.Text = "DP:";
            // 
            // txtDP
            // 
            txtDP.Location = new Point(534, 306);
            txtDP.Name = "txtDP";
            txtDP.Size = new Size(125, 27);
            txtDP.TabIndex = 24;
            // 
            // btncancelar
            // 
            btncancelar.Location = new Point(539, 361);
            btncancelar.Name = "btncancelar";
            btncancelar.Size = new Size(106, 39);
            btncancelar.TabIndex = 25;
            btncancelar.Text = "Cancelar";
            btncancelar.UseVisualStyleBackColor = true;
            btncancelar.Click += btncancelar_Click;
            // 
            // FormCotizar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 571);
            Controls.Add(btncancelar);
            Controls.Add(txtDP);
            Controls.Add(label13);
            Controls.Add(txtAdd);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(txtEjeOI);
            Controls.Add(txtCilindroOI);
            Controls.Add(txtEsferaOI);
            Controls.Add(txtEjeOD);
            Controls.Add(label6);
            Controls.Add(btnSiguiente);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(lblResultado);
            Controls.Add(btnCalcular);
            Controls.Add(txtCilindroOD);
            Controls.Add(txtEsferaOD);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormCotizar";
            Text = "FormCotizar";
            Load += FormCotizar_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtEsferaOD;
        private TextBox txtCilindroOD;
        private Button btnCalcular;
        private Label lblResultado;
        private Label label3;
        private Label label4;
        private Button btnSiguiente;
        private Label label6;
        private TextBox txtEjeOD;
        private TextBox txtEsferaOI;
        private TextBox txtCilindroOI;
        private TextBox txtEjeOI;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private TextBox txtAdd;
        private Label label13;
        private TextBox txtDP;
        private Button btncancelar;
    }
}