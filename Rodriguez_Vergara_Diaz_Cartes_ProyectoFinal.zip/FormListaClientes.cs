﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace LENTE_2
{
    public partial class FormListaClientes : Form
    {
        string archivo = "clientes.txt";
        private bool editando = false;

        // Control de búsqueda creado por código
        private TextBox txtBuscar;
        private Label lblBuscar;

        public FormListaClientes()
        {
            InitializeComponent();
            this.Activated += FormListaClientes_Activated;
        }

        private void FormListaClientes_Load(object sender, EventArgs e)
        {
            // 1. Crear la barra de búsqueda automáticamente
            CrearBuscador();

            // 2. Aplicar estilos y cargar
            Estilos.Aplicar(this);
            ConfigurarGrilla();
            CargarDatos(""); // Carga todo al inicio
        }

        private void CrearBuscador()
        {
            // Etiqueta
            lblBuscar = new Label();
            lblBuscar.Text = "🔍 Buscar Cliente (Nombre o RUT):";
            lblBuscar.AutoSize = true;
            lblBuscar.Location = new Point(20, 90); // Ajusta posición si choca
            lblBuscar.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblBuscar.ForeColor = Estilos.ColorPrimario; // Usamos el color de tu estilo
            this.Controls.Add(lblBuscar);

            // Caja de Texto
            txtBuscar = new TextBox();
            txtBuscar.Location = new Point(20, 115);
            txtBuscar.Width = 300;
            txtBuscar.Font = new Font("Segoe UI", 10);
            txtBuscar.KeyUp += TxtBuscar_KeyUp; // Evento al escribir
            this.Controls.Add(txtBuscar);
        }

        private void TxtBuscar_KeyUp(object sender, KeyEventArgs e)
        {
            // Cada vez que escribes, recarga la lista con el filtro
            CargarDatos(txtBuscar.Text.Trim().ToLower());
        }

        private void FormListaClientes_Activated(object sender, EventArgs e)
        {
            if (!editando) CargarDatos(txtBuscar != null ? txtBuscar.Text : "");
        }

        private void ConfigurarGrilla()
        {
            if (dataGridView1.Columns.Count == 0)
            {
                dataGridView1.Columns.Add("Id", "ID");
                dataGridView1.Columns.Add("Rut", "RUT");
                dataGridView1.Columns.Add("Nombre", "Nombre");
                dataGridView1.Columns.Add("Region", "Región");
                dataGridView1.Columns.Add("Comuna", "Comuna");
                dataGridView1.Columns.Add("Direccion", "Dirección");
                dataGridView1.Columns.Add("Telefono", "Teléfono");
                dataGridView1.Columns.Add("Email", "Email");
            }
            dataGridView1.Columns["Id"].Visible = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Importante para diseño
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Ajustar altura de la tabla para que quepa el buscador arriba
            dataGridView1.Location = new Point(12, 150);
            dataGridView1.Height = 350;
        }

        private void CargarDatos(string filtro)
        {
            dataGridView1.Rows.Clear();
            if (File.Exists(archivo))
            {
                List<string> lineas = GestorArchivos.Leer(archivo);
                foreach (string linea in lineas)
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(linea)) continue;
                        GestionClientes cli = GestionClientes.DesdeTexto(linea);

                        // LOGICA DE FILTRADO (Buscador)
                        bool coincide = string.IsNullOrEmpty(filtro) ||
                                        cli.Nombre.ToLower().Contains(filtro) ||
                                        cli.Rut.ToLower().Contains(filtro);

                        if (coincide)
                        {
                            dataGridView1.Rows.Add(cli.Id, cli.Rut, cli.Nombre, cli.Region, cli.Comuna, cli.Direccion, cli.Telefono, cli.Email);
                        }
                    }
                    catch { continue; }
                }
            }
        }

        // --- BOTONES --- (Igual que antes, solo actualizados para compilar)

        private void button4_Click(object sender, EventArgs e) // EDITAR
        {
            if (!editando)
            {
                editando = true;
                btneditar.Text = "Confirmar Cambios";
                btneditar.BackColor = Color.LightGreen;
                dataGridView1.ReadOnly = false;
                dataGridView1.Columns["Id"].ReadOnly = true;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.CellSelect;
                dataGridView1.DefaultCellStyle.BackColor = Color.White;
                button2.Enabled = false;
                btnactualizardatos.Enabled = false;
                btnVolver.Enabled = false;
                MessageBox.Show("MODO EDICIÓN ACTIVADO");
            }
            else
            {
                GuardarCambiosDesdeTabla();
                editando = false;
                btneditar.Text = "Editar Cliente";
                btneditar.BackColor = SystemColors.Control;
                dataGridView1.ReadOnly = true;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dataGridView1.DefaultCellStyle.BackColor = SystemColors.Window;
                button2.Enabled = true;
                btnactualizardatos.Enabled = true;
                btnVolver.Enabled = true;
                MessageBox.Show("¡Cambios guardados!");
                // Re-aplicar estilos para asegurar colores correctos
                Estilos.Aplicar(this);
            }
        }

        private void GuardarCambiosDesdeTabla()
        {
            try
            {
                List<string> lineasParaGuardar = new List<string>();
                foreach (DataGridViewRow fila in dataGridView1.Rows)
                {
                    if (fila.IsNewRow) continue;
                    string id = (fila.Cells[0].Value?.ToString() ?? "").Replace("|", "");
                    string rut = (fila.Cells[1].Value?.ToString() ?? "").Replace("|", "");
                    string nombre = (fila.Cells[2].Value?.ToString() ?? "").Replace("|", "");
                    string region = (fila.Cells[3].Value?.ToString() ?? "").Replace("|", "");
                    string comuna = (fila.Cells[4].Value?.ToString() ?? "").Replace("|", "");
                    string dire = (fila.Cells[5].Value?.ToString() ?? "").Replace("|", "");
                    string fono = (fila.Cells[6].Value?.ToString() ?? "").Replace("|", "");
                    string email = (fila.Cells[7].Value?.ToString() ?? "").Replace("|", "");

                    string linea = $"{id}|{rut}|{nombre}|{region}|{comuna}|{dire}|{fono}|{email}";
                    lineasParaGuardar.Add(linea);
                }
                File.WriteAllLines(archivo, lineasParaGuardar);
            }
            catch (Exception ex) { MessageBox.Show("Error al guardar: " + ex.Message); }
        }

        private void button2_Click(object sender, EventArgs e) // ELIMINAR
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string nombre = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                if (MessageBox.Show($"¿Eliminar a {nombre}?", "Confirmar", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                    GuardarCambiosDesdeTabla();
                    MessageBox.Show("Cliente eliminado.");
                }
            }
            else { MessageBox.Show("Selecciona una fila completa para eliminar."); }
        }

        private void label1_Click(object sender, EventArgs e) { CargarDatos(txtBuscar.Text); }
        private void btnVolver_Click(object sender, EventArgs e) { this.Close(); }
    }
}