﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Globalization;

namespace LENTE_2
{
    public partial class FormCotizar : Form
    {
        // Variable Estática para guardar el precio y que FormClientes lo pueda leer
        public static decimal PrecioRecetaPendiente = 0;
        public static string DetalleRecetaPendiente = "";

        public FormCotizar()
        {
            InitializeComponent();

            // Validaciones de teclado
            txtEsferaOD.KeyPress += ValidarEntradaTeclado;
            txtCilindroOD.KeyPress += ValidarEntradaTeclado;
            txtEjeOD.KeyPress += ValidarSoloNumerosEnteros;
            txtEsferaOI.KeyPress += ValidarEntradaTeclado;
            txtCilindroOI.KeyPress += ValidarEntradaTeclado;
            txtEjeOI.KeyPress += ValidarSoloNumerosEnteros;
            txtAdd.KeyPress += ValidarEntradaTeclado;
            txtDP.KeyPress += ValidarEntradaTeclado;
        }

        private void FormCotizar_Load(object sender, EventArgs e)
        {
            Estilos.Aplicar(this);
        }

        // --- LÓGICA DE TECLADO (Igual que antes) ---
        private void ValidarEntradaTeclado(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == ',') e.KeyChar = '.';
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && (e.KeyChar != '-')) e.Handled = true;
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1) e.Handled = true;
            if (e.KeyChar == '-' && (sender as TextBox).SelectionStart != 0) e.Handled = true;
        }

        private void ValidarSoloNumerosEnteros(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
        }

        private decimal ParsearAmericano(string texto)
        {
            string t = texto.Replace(",", ".");
            return decimal.TryParse(t, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal v) ? v : -9999;
        }

        // --- LÓGICA DE CÁLCULO ---
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEsferaOD.Text) || string.IsNullOrWhiteSpace(txtCilindroOD.Text) ||
                string.IsNullOrWhiteSpace(txtEjeOD.Text) || string.IsNullOrWhiteSpace(txtEsferaOI.Text) ||
                string.IsNullOrWhiteSpace(txtCilindroOI.Text) || string.IsNullOrWhiteSpace(txtEjeOI.Text) ||
                string.IsNullOrWhiteSpace(txtAdd.Text) || string.IsNullOrWhiteSpace(txtDP.Text))
            {
                MessageBox.Show("⚠️ Debe llenar TODOS los campos.", "Datos Faltantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal esfOD = ParsearAmericano(txtEsferaOD.Text);
            decimal cilOD = ParsearAmericano(txtCilindroOD.Text);
            decimal esfOI = ParsearAmericano(txtEsferaOI.Text);
            decimal cilOI = ParsearAmericano(txtCilindroOI.Text);
            decimal add = ParsearAmericano(txtAdd.Text);

            if (esfOD == -9999 || cilOD == -9999 || esfOI == -9999 || cilOI == -9999 || add == -9999)
            {
                MessageBox.Show("Error de formato numérico.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            esfOD = Math.Abs(esfOD);
            cilOD = Math.Abs(cilOD);
            esfOI = Math.Abs(esfOI);
            cilOI = Math.Abs(cilOI);

            string nombreLente = "MONOFOCAL";
            decimal precio = 0;

            if (add > 0)
            {
                if (MessageBox.Show("¿Es Multifocal?\nSÍ = Multifocal\nNO = Bifocal", "Tipo", MessageBoxButtons.YesNo) == DialogResult.Yes)
                { nombreLente = "MULTIFOCAL"; precio = 110990; }
                else { nombreLente = "BIFOCAL"; precio = 79990; }
            }

            if (precio == 0)
            {
                decimal esfFinalOD = esfOD + add;
                decimal esfFinalOI = esfOI + add;
                int rango = Math.Max(CalcularRango(esfFinalOD, cilOD), CalcularRango(esfFinalOI, cilOI));

                switch (rango)
                {
                    case 1: precio = 29990; break;
                    case 2: precio = 39990; break;
                    case 3: precio = 49990; break;
                    default: nombreLente = "CONSULTAR (Alta Graduación)"; precio = 0; break;
                }
            }

            // GUARDAMOS EN VARIABLES ESTÁTICAS PARA QUE SOBREVIVAN AL CAMBIO DE FORM
            PrecioRecetaPendiente = precio;
            DetalleRecetaPendiente = nombreLente;

            lblResultado.Text = $"LENTE: {nombreLente}\nPRECIO: ${precio:N0}\nDP: {txtDP.Text}";
        }

        private int CalcularRango(decimal esf, decimal cil)
        {
            if (esf > 8 || cil > 6) return 4;
            if (esf > 6 || cil > 4) return 3;
            if (esf > 3 || cil > 2) return 2;
            return 1;
        }

        // --- BOTÓN CONTINUAR (CORREGIDO: VA A FORMCLIENTES) ---
        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            if (PrecioRecetaPendiente == 0 && DetalleRecetaPendiente != "CONSULTAR (Alta Graduación)")
            {
                MessageBox.Show("⚠️ Primero presione 'Calcular'.", "Atención");
                return;
            }

            this.Hide();

            // AHORA ABRE CLIENTES, NO VENTAS DIRECTAMENTE
            FormClientes ventanaClientes = new FormClientes();
            ventanaClientes.ShowDialog();

            this.Close();
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEsferaOD.Text))
            {
                if (MessageBox.Show("¿Limpiar formulario?", "Cancelar", MessageBoxButtons.YesNo) == DialogResult.No) return;
            }

            txtEsferaOD.Clear(); txtCilindroOD.Clear(); txtEjeOD.Clear();
            txtEsferaOI.Clear(); txtCilindroOI.Clear(); txtEjeOI.Clear();
            txtAdd.Clear(); txtDP.Clear();
            lblResultado.Text = "Resultado:";
            PrecioRecetaPendiente = 0;
        }

        private void btnContinuar_Click(object sender, EventArgs e) { btnSiguiente_Click(sender, e); }
        private void txtAdd_TextChanged(object sender, EventArgs e) { }
        private void txtDP_TextChanged(object sender, EventArgs e) { }
        private void txtEsferaOD_TextChanged(object sender, EventArgs e) { }
    }
}