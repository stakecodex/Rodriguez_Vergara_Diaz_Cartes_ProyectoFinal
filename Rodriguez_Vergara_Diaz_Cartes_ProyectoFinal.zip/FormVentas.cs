﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace LENTE_2
{
    public partial class FormVentas : Form
    {
        // VARIABLES CLASE
        string archivoVentas = "ventas.txt";
        string rutPreseleccionado = "";
        decimal precioRecetaTraida = 0;
        string descripcionReceta = "";

        // Estado de edición
        private bool editando = false;

        List<GestionClientes> listaClientes = new List<GestionClientes>();
        List<Inventario> listaProductos = new List<Inventario>();

        public FormVentas(string rut = "", decimal precioReceta = 0, string detalleReceta = "")
        {
            InitializeComponent();
            rutPreseleccionado = rut;
            precioRecetaTraida = precioReceta;
            descripcionReceta = detalleReceta;

            this.Activated += FormVentas_Activated;
        }

        private void FormVentas_Load(object sender, EventArgs e)
        {
            Estilos.Aplicar(this);
            ConfigurarGrilla();
            CargarDatosPantalla();

            // Configuración inicial del botón con el nombre correcto
            btneditarcliente.Text = "Editar Venta Seleccionada";
            editando = false;

            if (!string.IsNullOrEmpty(rutPreseleccionado)) SeleccionarClientePorRut(rutPreseleccionado);
        }

        // ═══════════════════════════════════════════════════════════
        // LÓGICA DEL BOTÓN EDITAR (btneditarcliente)
        // ═══════════════════════════════════════════════════════════
        private void btneditarcliente_Click(object sender, EventArgs e)
        {
            try
            {
                if (!editando)
                {
                    // --- FASE 1: CARGAR DATOS PARA EDITAR ---
                    if (dataGridView1.SelectedRows.Count == 0)
                    {
                        MessageBox.Show("Selecciona una venta de la lista para editar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // 1. Cargar datos de la grilla a los controles
                    CargarDatosDeLaGrillaAControles();

                    // 2. Cambiar estado visual
                    editando = true;
                    btneditarcliente.Text = "Confirmar Cambios";
                    btneditarcliente.BackColor = Estilos.ColorExito; // Verde

                    // 3. Bloquear creación de nuevas ventas mientras se edita
                    btnVenta.Enabled = false;
                    btnEliminar.Enabled = false;
                    dataGridView1.Enabled = false; // Bloquear tabla para no cambiar de fila

                    MessageBox.Show("✏️ MODO EDICIÓN ACTIVADO\nLos datos se han cargado arriba. Modifíquelos y presione 'Confirmar Cambios'.", "Editar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    // --- FASE 2: GUARDAR LOS CAMBIOS (SOBRESCRIBIR) ---

                    if (cmbClientes.SelectedIndex == -1 || cmbProductos.SelectedIndex == -1)
                    {
                        MessageBox.Show("No puede dejar el cliente o producto vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Ejecutar la lógica de actualización
                    ActualizarVentaEnArchivo();

                    // Restaurar estado
                    editando = false;
                    btneditarcliente.Text = "Editar Venta Seleccionada";
                    btneditarcliente.BackColor = Color.Orange;

                    // Reactivar controles
                    btnVenta.Enabled = true;
                    btnEliminar.Enabled = true;
                    dataGridView1.Enabled = true;

                    // Limpiar y recargar
                    btnLimpiar_Click(null, null);
                    CargarHistorialVentas();

                    Estilos.Aplicar(this); // Re-aplicar estilos

                    MessageBox.Show("✅ Venta actualizada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en el proceso: " + ex.Message);
            }
        }

        // Métodos auxiliares para la edición
        private void CargarDatosDeLaGrillaAControles()
        {
            DataGridViewRow fila = dataGridView1.SelectedRows[0];

            string rutGrid = fila.Cells[2].Value.ToString();
            SeleccionarClientePorRut(rutGrid);

            string prodGrid = fila.Cells[3].Value.ToString();
            for (int i = 0; i < cmbProductos.Items.Count; i++)
            {
                if (cmbProductos.Items[i].ToString().Contains(prodGrid))
                {
                    cmbProductos.SelectedIndex = i;
                    break;
                }
            }

            string extras = fila.Cells[5].Value.ToString();
            chkAzul.Checked = extras.Contains("Azul");
            chkFoto.Checked = extras.Contains("Foto");
            chkPoli.Checked = extras.Contains("Poli");
            chkTenido.Checked = extras.Contains("Teñido");
            chkAntiReflejo.Checked = extras.Contains("AntiReflejo");

            if (extras.Contains("1.67")) cmbadelgazado.SelectedIndex = 1;
            else cmbadelgazado.SelectedIndex = 0;
        }

        private void ActualizarVentaEnArchivo()
        {
            GestionClientes cliente = listaClientes[cmbClientes.SelectedIndex];
            Inventario producto = listaProductos[cmbProductos.SelectedIndex];

            decimal total = producto.PrecioBase;
            string detallesExtras = "";

            if (chkAzul.Checked) { total += 8000; detallesExtras += "Azul, "; }
            if (chkFoto.Checked) { total += 10000; detallesExtras += "Foto, "; }
            if (chkPoli.Checked) { total += 10000; detallesExtras += "Poli, "; }
            if (chkTenido.Checked) { total += 5000; detallesExtras += "Teñido, "; }
            if (chkAntiReflejo.Checked) { total += 5000; detallesExtras += "AntiReflejo, "; }
            if (cmbadelgazado.Text.Contains("1.67")) { total += 50000; detallesExtras += "Adelgazado 1.67, "; }

            total += CalcularEnvio(cliente.Region);

            int indiceFila = dataGridView1.SelectedRows[0].Index;
            string idOriginal = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            List<string> lineas = GestorArchivos.Leer(archivoVentas);

            string nuevaLinea = $"{idOriginal}|{DateTime.Now}|{cliente.Rut}|{producto.CodigoModelo}|{total}|{detallesExtras}";

            if (indiceFila >= 0 && indiceFila < lineas.Count)
            {
                lineas[indiceFila] = nuevaLinea;
                File.WriteAllLines(archivoVentas, lineas);
            }
        }

        // ═══════════════════════════════════════════════════════════
        // RESTO DE MÉTODOS (Carga, Guardar Nuevo, Eliminar)
        // ═══════════════════════════════════════════════════════════

        private void FormVentas_Activated(object sender, EventArgs e)
        {
            if (!editando)
            {
                CargarHistorialVentas();
                CargarCombos();
            }
        }

        private void ConfigurarGrilla()
        {
            if (dataGridView1.Columns.Count == 0)
            {
                dataGridView1.Columns.Add("Id", "ID Venta");
                dataGridView1.Columns.Add("Fecha", "Fecha");
                dataGridView1.Columns.Add("Rut", "Rut Cliente");
                dataGridView1.Columns.Add("Producto", "Lente");
                dataGridView1.Columns.Add("Total", "Total");
                dataGridView1.Columns.Add("Extras", "Extras");
            }
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.AllowUserToAddRows = false;
        }

        private void CargarDatosPantalla()
        {
            CargarCombos();
            CargarOpcionesAdelgazado();
            CargarHistorialVentas();
        }

        private void SeleccionarClientePorRut(string rut)
        {
            for (int i = 0; i < listaClientes.Count; i++)
            {
                if (listaClientes[i].Rut == rut) { cmbClientes.SelectedIndex = i; break; }
            }
        }

        private void CargarOpcionesAdelgazado()
        {
            cmbadelgazado.Items.Clear();
            cmbadelgazado.Items.Add("Estándar (Índice 1.56) - Sin costo");
            cmbadelgazado.Items.Add("Adelgazado (Índice 1.67) - +$50.000");
            cmbadelgazado.SelectedIndex = 0;
        }

        private void CargarCombos()
        {
            int indiceCliente = cmbClientes.SelectedIndex;
            int indiceProducto = cmbProductos.SelectedIndex;

            cmbClientes.Items.Clear();
            listaClientes.Clear();

            if (File.Exists("clientes.txt"))
            {
                var lineas = GestorArchivos.Leer("clientes.txt");
                foreach (var linea in lineas)
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(linea)) continue;
                        GestionClientes cli = GestionClientes.DesdeTexto(linea);
                        listaClientes.Add(cli);
                        cmbClientes.Items.Add($"{cli.Rut} - {cli.Nombre}");
                    }
                    catch { }
                }
            }

            cmbProductos.Items.Clear();
            listaProductos.Clear();

            if (File.Exists("inventario.txt"))
            {
                var lineas = GestorArchivos.Leer("inventario.txt");
                foreach (var linea in lineas)
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(linea)) continue;
                        Inventario prod = Inventario.DesdeTexto(linea);
                        if (prod.Stock > 0)
                        {
                            listaProductos.Add(prod);
                            cmbProductos.Items.Add($"{prod.CodigoModelo} - ${prod.PrecioBase}");
                        }
                    }
                    catch { }
                }
            }

            if (indiceCliente < cmbClientes.Items.Count) cmbClientes.SelectedIndex = indiceCliente;
            if (indiceProducto < cmbProductos.Items.Count) cmbProductos.SelectedIndex = indiceProducto;
        }

        private void btnVenta_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbClientes.SelectedIndex == -1 || cmbProductos.SelectedIndex == -1)
                {
                    MessageBox.Show("Seleccione un Cliente y un Producto.");
                    return;
                }

                GestionClientes cliente = listaClientes[cmbClientes.SelectedIndex];
                Inventario producto = listaProductos[cmbProductos.SelectedIndex];

                if (producto.Stock <= 0)
                {
                    MessageBox.Show("¡No queda stock!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                decimal total = producto.PrecioBase + precioRecetaTraida;
                string detallesExtras = "";

                if (precioRecetaTraida > 0) detallesExtras += $"Receta ({descripcionReceta}: ${precioRecetaTraida:N0}), ";

                if (chkAzul.Checked) { total += 8000; detallesExtras += "Azul, "; }
                if (chkFoto.Checked) { total += 10000; detallesExtras += "Foto, "; }
                if (chkPoli.Checked) { total += 10000; detallesExtras += "Poli, "; }
                if (chkTenido.Checked) { total += 5000; detallesExtras += "Teñido, "; }
                if (chkAntiReflejo.Checked) { total += 5000; detallesExtras += "AntiReflejo, "; }

                if (cmbadelgazado.Text.Contains("1.67"))
                {
                    total += 50000;
                    detallesExtras += "Adelgazado 1.67, ";
                }

                decimal costoEnvio = CalcularEnvio(cliente.Region);
                total += costoEnvio;

                lblTotal.Text = "$ " + total.ToString("N0");

                DialogResult respuesta = MessageBox.Show(
                    $"Cliente: {cliente.Nombre}\nTotal: ${total:N0}\n\n¿Confirmar Venta y Generar Boleta?",
                    "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (respuesta == DialogResult.Yes)
                {
                    GuardarVenta(cliente, producto, total, detallesExtras, costoEnvio);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            cmbClientes.SelectedIndex = -1;
            cmbProductos.SelectedIndex = -1;
            cmbadelgazado.SelectedIndex = 0;
            chkAzul.Checked = false;
            chkFoto.Checked = false;
            chkPoli.Checked = false;
            chkTenido.Checked = false;
            chkAntiReflejo.Checked = false;
            lblTotal.Text = "$ 0";

            // Si cancelamos la edición
            if (editando)
            {
                editando = false;
                btneditarcliente.Text = "Editar Venta Seleccionada";
                btneditarcliente.BackColor = Color.Orange;
                btnVenta.Enabled = true;
                btnEliminar.Enabled = true;
                dataGridView1.Enabled = true;
                Estilos.Aplicar(this);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Selecciona una venta para eliminar.");
                    return;
                }

                if (MessageBox.Show("¿Eliminar esta venta?", "Confirmar", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    int indiceFila = dataGridView1.SelectedRows[0].Index;
                    List<string> lineas = GestorArchivos.Leer(archivoVentas);

                    if (indiceFila >= 0 && indiceFila < lineas.Count)
                    {
                        lineas.RemoveAt(indiceFila);
                        File.WriteAllLines(archivoVentas, lineas);
                        CargarHistorialVentas();
                        MessageBox.Show("Venta eliminada.");
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private decimal CalcularEnvio(string region)
        {
            if (region.Contains("Metropolitana")) return 3000;
            if (region.Contains("Coquimbo") || region.Contains("Valparaíso") || region.Contains("O'Higgins") || region.Contains("Maule") || region.Contains("Ñuble") || region.Contains("Biobío")) return 5000;
            if (region.Contains("Arica") || region.Contains("Tarapacá") || region.Contains("Antofagasta") || region.Contains("Atacama")) return 6000;
            if (region.Contains("Araucanía") || region.Contains("Los Ríos") || region.Contains("Los Lagos")) return 6000;
            if (region.Contains("Aysén") || region.Contains("Magallanes")) return 10000;
            return 6000;
        }

        private void GuardarVenta(GestionClientes cli, Inventario prod, decimal total, string extras, decimal envio)
        {
            int nuevoId = 1;
            List<string> lineasVentas = GestorArchivos.Leer(archivoVentas);
            if (lineasVentas.Count > 0)
            {
                try { nuevoId = lineasVentas.Select(l => int.Parse(l.Split('|')[0])).Max() + 1; }
                catch { nuevoId = lineasVentas.Count + 1; }
            }

            string lineaVenta = $"{nuevoId}|{DateTime.Now}|{cli.Rut}|{prod.CodigoModelo}|{total}|{extras}";
            GestorArchivos.Guardar(archivoVentas, lineaVenta);

            DescontarStock(prod);
            GenerarBoleta(nuevoId, cli, prod, total, extras, envio);

            MessageBox.Show($"¡Venta Guardada! Boleta N° {nuevoId} generada.");

            btnLimpiar_Click(null, null);
            CargarHistorialVentas();
            CargarCombos();

            if (MessageBox.Show("¿Desea volver al Menú Principal?", "Finalizar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void GenerarBoleta(int idVenta, GestionClientes cli, Inventario prod, decimal total, string extras, decimal envio)
        {
            try
            {
                string nombreArchivo = $"Boleta_{idVenta}.txt";
                using (StreamWriter sw = new StreamWriter(nombreArchivo))
                {
                    sw.WriteLine("==========================================");
                    sw.WriteLine("           MUNDO VISIÓN ÓPTICAS           ");
                    sw.WriteLine("==========================================");
                    sw.WriteLine($"Fecha: {DateTime.Now}");
                    sw.WriteLine($"Boleta N°: {idVenta}");
                    sw.WriteLine("------------------------------------------");
                    sw.WriteLine("DATOS CLIENTE:");
                    sw.WriteLine($"Nombre: {cli.Nombre}");
                    sw.WriteLine($"RUT:    {cli.Rut}");
                    sw.WriteLine($"Fono:   {cli.Telefono}");
                    sw.WriteLine("------------------------------------------");
                    sw.WriteLine("DETALLE PRODUCTO:");
                    sw.WriteLine($"Marco:  {prod.CodigoModelo}");
                    sw.WriteLine($"Precio Base: ${prod.PrecioBase:N0}");
                    sw.WriteLine($"Extras: {extras}");
                    sw.WriteLine($"Envío:  ${envio:N0}");
                    sw.WriteLine("------------------------------------------");
                    sw.WriteLine($"TOTAL A PAGAR: ${total:N0}");
                    sw.WriteLine("==========================================");
                    sw.WriteLine("      ¡Gracias por su preferencia!        ");
                    sw.WriteLine("==========================================");
                }
                Process.Start("notepad.exe", nombreArchivo);
            }
            catch { }
        }

        private void DescontarStock(Inventario prodVendido)
        {
            List<string> lineas = GestorArchivos.Leer("inventario.txt");
            List<string> nuevasLineas = new List<string>();
            foreach (string linea in lineas)
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(linea)) continue;
                    Inventario p = Inventario.DesdeTexto(linea);
                    if (p.Id == prodVendido.Id) p.Stock = p.Stock - 1;
                    nuevasLineas.Add(p.ATexto());
                }
                catch { }
            }
            File.WriteAllLines("inventario.txt", nuevasLineas);
        }

        private void CargarHistorialVentas()
        {
            dataGridView1.Rows.Clear();
            decimal sumaTotalVentas = 0;

            if (File.Exists(archivoVentas))
            {
                var lineas = GestorArchivos.Leer(archivoVentas);
                foreach (var linea in lineas)
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(linea)) continue;
                        VentasCotizaciones venta = VentasCotizaciones.DesdeTexto(linea);
                        dataGridView1.Rows.Add(venta.Id, venta.Fecha.ToShortDateString(), venta.RutCliente, venta.CodigoProducto, "$" + venta.TotalPagar.ToString("N0"), venta.Extras);
                        sumaTotalVentas += venta.TotalPagar;
                    }
                    catch { continue; }
                }
            }
            this.Text = $"Gestión de Ventas - TOTAL VENTAS: ${sumaTotalVentas:N0}";
        }

        private void lblTotal_Click(object sender, EventArgs e) { }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }
}