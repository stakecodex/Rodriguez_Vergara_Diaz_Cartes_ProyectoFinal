﻿namespace LENTE_2
{
    partial class FormListaClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            btnVolver = new Button();
            btnactualizardatos = new Button();
            button2 = new Button();
            btneditar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 82);
            label2.Name = "label2";
            label2.Size = new Size(776, 480);
            label2.TabIndex = 2;
            label2.Text = "Lista de Clientes";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(63, 3);
            label1.Name = "label1";
            label1.Size = new Size(674, 62);
            label1.TabIndex = 3;
            label1.Text = "Sistema de Gestión de Ópticas";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 115);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(776, 409);
            dataGridView1.TabIndex = 4;
            // 
            // btnVolver
            // 
            btnVolver.Location = new Point(613, 530);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(165, 29);
            btnVolver.TabIndex = 5;
            btnVolver.Text = "Volver al Menú";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // btnactualizardatos
            // 
            btnactualizardatos.Location = new Point(77, 530);
            btnactualizardatos.Name = "btnactualizardatos";
            btnactualizardatos.Size = new Size(170, 29);
            btnactualizardatos.TabIndex = 6;
            btnactualizardatos.Text = "Actualizar Datos";
            btnactualizardatos.UseVisualStyleBackColor = true;
            btnactualizardatos.Click += label1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(268, 530);
            button2.Name = "button2";
            button2.Size = new Size(123, 29);
            button2.TabIndex = 7;
            button2.Text = "Eliminar Cliente";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // btneditar
            // 
            btneditar.Location = new Point(424, 530);
            btneditar.Name = "btneditar";
            btneditar.Size = new Size(151, 29);
            btneditar.TabIndex = 8;
            btneditar.Text = "Editar Cliente";
            btneditar.UseVisualStyleBackColor = true;
            btneditar.Click += button4_Click;
            // 
            // FormListaClientes
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 571);
            Controls.Add(btneditar);
            Controls.Add(button2);
            Controls.Add(btnactualizardatos);
            Controls.Add(btnVolver);
            Controls.Add(dataGridView1);
            Controls.Add(label1);
            Controls.Add(label2);
            Name = "FormListaClientes";
            Text = "FormListaClientes";
            Load += FormListaClientes_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.Button btnactualizardatos;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btneditar;
    }
}