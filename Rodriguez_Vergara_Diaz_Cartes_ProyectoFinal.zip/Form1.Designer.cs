﻿namespace LENTE_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbltitulo = new Label();
            label2 = new Label();
            btnCotizar = new Button();
            btnClientes = new Button();
            btnVentas = new Button();
            btnInventario = new Button();
            btnsalir = new Button();
            btnVerLista = new Button();
            SuspendLayout();
            // 
            // lbltitulo
            // 
            lbltitulo.AutoSize = true;
            lbltitulo.Font = new Font("Segoe UI Semibold", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbltitulo.Location = new Point(63, 2);
            lbltitulo.Name = "lbltitulo";
            lbltitulo.Size = new Size(674, 62);
            lbltitulo.TabIndex = 0;
            lbltitulo.Text = "Sistema de Gestión de Ópticas";
            lbltitulo.TextAlign = ContentAlignment.TopCenter;
            lbltitulo.Click += label1_Click;
            // 
            // label2
            // 
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 82);
            label2.Name = "label2";
            label2.Size = new Size(776, 480);
            label2.TabIndex = 1;
            label2.Text = "Menu Principal";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // btnCotizar
            // 
            btnCotizar.Location = new Point(301, 160);
            btnCotizar.Name = "btnCotizar";
            btnCotizar.Size = new Size(202, 40);
            btnCotizar.TabIndex = 2;
            btnCotizar.Text = "Cotizar Receta";
            btnCotizar.UseVisualStyleBackColor = true;
            btnCotizar.Click += btncotizarreceta_Click_1;
            // 
            // btnClientes
            // 
            btnClientes.Location = new Point(301, 215);
            btnClientes.Name = "btnClientes";
            btnClientes.Size = new Size(202, 40);
            btnClientes.TabIndex = 3;
            btnClientes.Text = "Gestion de Clientes";
            btnClientes.UseVisualStyleBackColor = true;
            btnClientes.Click += btnClientes_Click;
            // 
            // btnVentas
            // 
            btnVentas.Location = new Point(301, 273);
            btnVentas.Name = "btnVentas";
            btnVentas.Size = new Size(202, 40);
            btnVentas.TabIndex = 4;
            btnVentas.Text = "Ventas y Cotizaciones";
            btnVentas.UseVisualStyleBackColor = true;
            btnVentas.Click += btnVentas_Click;
            // 
            // btnInventario
            // 
            btnInventario.Location = new Point(301, 331);
            btnInventario.Name = "btnInventario";
            btnInventario.Size = new Size(202, 40);
            btnInventario.TabIndex = 5;
            btnInventario.Text = "Inventario";
            btnInventario.UseVisualStyleBackColor = true;
            btnInventario.Click += btnInventario_Click;
            // 
            // btnsalir
            // 
            btnsalir.Location = new Point(670, 520);
            btnsalir.Name = "btnsalir";
            btnsalir.Size = new Size(94, 29);
            btnsalir.TabIndex = 6;
            btnsalir.Text = "Salir";
            btnsalir.UseVisualStyleBackColor = true;
            btnsalir.Click += btnsalir_Click;
            // 
            // btnVerLista
            // 
            btnVerLista.Location = new Point(301, 389);
            btnVerLista.Name = "btnVerLista";
            btnVerLista.Size = new Size(202, 40);
            btnVerLista.TabIndex = 7;
            btnVerLista.Text = "Ver Lista de Clientes";
            btnVerLista.UseVisualStyleBackColor = true;
            btnVerLista.Click += btnVerLista_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 571);
            Controls.Add(btnVerLista);
            Controls.Add(btnsalir);
            Controls.Add(btnInventario);
            Controls.Add(btnVentas);
            Controls.Add(btnClientes);
            Controls.Add(btnCotizar);
            Controls.Add(label2);
            Controls.Add(lbltitulo);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbltitulo;
        private Label label2;
        private Button btnCotizar;
        private Button btnClientes;
        private Button btnVentas;
        private Button btnInventario;
        private Button btnsalir;
        private Button btnVerLista;
    }
}
