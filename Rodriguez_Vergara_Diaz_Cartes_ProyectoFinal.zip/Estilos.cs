﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace LENTE_2
{
    public static class Estilos
    {
        // ═══════════════════════════════════════════════════════════
        // PALETA DE COLORES (SOLO PINTURA)
        // ═══════════════════════════════════════════════════════════
        public static readonly Color ColorFondo = ColorTranslator.FromHtml("#F4F7F6");
        public static readonly Color ColorPrimario = ColorTranslator.FromHtml("#005A9C"); // Azul
        public static readonly Color ColorSecundario = ColorTranslator.FromHtml("#2980B9"); // Azul claro
        public static readonly Color ColorExito = ColorTranslator.FromHtml("#27AE60"); // Verde
        public static readonly Color ColorPeligro = ColorTranslator.FromHtml("#C0392B"); // Rojo
        public static readonly Color ColorTexto = ColorTranslator.FromHtml("#2C3E50"); // Gris oscuro
        public static readonly Color ColorBlanco = Color.White;
        public static readonly Color ColorFoco = ColorTranslator.FromHtml("#D6EAF8");

        public static void Aplicar(Form formulario)
        {
            // 1. Solo cambiamos el color de fondo del formulario
            formulario.BackColor = ColorFondo;
            formulario.StartPosition = FormStartPosition.CenterScreen;

            // Doble buffer para que no parpadee, pero sin mover nada
            typeof(Control).GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.NonPublic |
                System.Reflection.BindingFlags.Instance)
                ?.SetValue(formulario, true, null);

            foreach (Control c in formulario.Controls)
            {
                EstilizarControl(c);
            }
        }

        private static void EstilizarControl(Control c)
        {
            if (c is Button btn) ConfigurarBoton(btn);
            else if (c is Label lbl) ConfigurarEtiqueta(lbl);
            else if (c is TextBox txt) ConfigurarTextBox(txt);
            else if (c is ComboBox cmb) ConfigurarComboBox(cmb);
            else if (c is DataGridView dgv) ConfigurarDataGridView(dgv);
            else if (c is Panel pnl) ConfigurarPanel(pnl);
            else if (c is GroupBox gb) ConfigurarGroupBox(gb);

            if (c.HasChildren)
            {
                foreach (Control hijo in c.Controls) EstilizarControl(hijo);
            }
        }

        // ═══════════════════════════════════════════════════════════
        // ETIQUETAS: SOLO COLOR Y TRANSPARENCIA (CERO CAMBIOS DE TAMAÑO)
        // ═══════════════════════════════════════════════════════════
        private static void ConfigurarEtiqueta(Label lbl)
        {
            lbl.BackColor = Color.Transparent; // Quita el fondo gris

            // Si el texto contiene "Sistema", asumimos que es el título principal y lo pintamos azul
            if (lbl.Text.Contains("Sistema") || lbl.Text.Contains("Mundo Visión"))
            {
                lbl.ForeColor = ColorPrimario;
                // NO CAMBIAMOS FONT NI SIZE. SE QUEDA COMO TÚ LO PUSISTE.
            }
            // Si la letra ya es grande o negrita en el diseño, la pintamos azul
            else if (lbl.Font.Size > 10 || lbl.Font.Bold)
            {
                lbl.ForeColor = ColorPrimario;
            }
            else
            {
                lbl.ForeColor = ColorTexto;
            }
        }

        // ═══════════════════════════════════════════════════════════
        // BOTONES: SOLO COLOR Y BORDE REDONDO (RESPETA TAMAÑO ORIGINAL)
        // ═══════════════════════════════════════════════════════════
        private static void ConfigurarBoton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Cursor = Cursors.Hand;
            btn.ForeColor = ColorBlanco;

            // IMPORTANTE: Eliminé cualquier línea que diga btn.Width = ... o btn.Height = ...
            // Se quedarán del tamaño exacto que tienen en tu diseño visual.

            string txt = btn.Text.ToUpper();
            Color colorBase = ColorSecundario;

            if (txt.Contains("ELIMINAR") || txt.Contains("SALIR") || txt.Contains("CANCELAR"))
                colorBase = ColorPeligro;
            else if (txt.Contains("GUARDAR") || txt.Contains("VENDER") || txt.Contains("CALCULAR") || txt.Contains("CONTINUAR"))
                colorBase = ColorExito;
            else if (txt.Contains("EDITAR") || txt.Contains("MODIFICAR"))
                colorBase = Color.Orange;

            btn.BackColor = colorBase;

            // Pintamos el borde redondeado DENTRO del área actual
            btn.Paint += (sender, e) =>
            {
                Button b = (Button)sender;
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                Rectangle rect = new Rectangle(0, 0, b.Width - 1, b.Height - 1);
                using (GraphicsPath path = Redondear(rect, 8))
                {
                    b.Region = new Region(path);
                    using (Pen pen = new Pen(ControlPaint.Light(b.BackColor, 0.2f), 1))
                    {
                        e.Graphics.DrawPath(pen, path);
                    }
                }
            };

            btn.MouseEnter += (s, e) => btn.BackColor = ControlPaint.Light(colorBase, 0.2f);
            btn.MouseLeave += (s, e) => btn.BackColor = colorBase;
        }

        // ═══════════════════════════════════════════════════════════
        // CAJAS DE TEXTO: SOLO COLOR (RESPETA TAMAÑO Y FUENTE)
        // ═══════════════════════════════════════════════════════════
        private static void ConfigurarTextBox(TextBox txt)
        {
            txt.BackColor = ColorBlanco;
            txt.BorderStyle = BorderStyle.FixedSingle;
            txt.Enter += (s, e) => txt.BackColor = ColorFoco; // Ilumina al entrar
            txt.Leave += (s, e) => txt.BackColor = ColorBlanco;
        }

        private static void ConfigurarComboBox(ComboBox cmb)
        {
            cmb.BackColor = ColorBlanco;
            cmb.FlatStyle = FlatStyle.Flat;
        }

        // ═══════════════════════════════════════════════════════════
        // TABLA: SOLO COLORES (NO CAMBIA ANCHOS)
        // ═══════════════════════════════════════════════════════════
        private static void ConfigurarDataGridView(DataGridView dgv)
        {
            dgv.BackgroundColor = ColorFondo;
            dgv.BorderStyle = BorderStyle.None;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.EnableHeadersVisualStyles = false;

            // Cabecera
            dgv.ColumnHeadersDefaultCellStyle.BackColor = ColorPrimario;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = ColorBlanco;
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;

            // Filas
            dgv.DefaultCellStyle.BackColor = ColorBlanco;
            dgv.DefaultCellStyle.ForeColor = ColorTexto;
            dgv.DefaultCellStyle.SelectionBackColor = ColorSecundario;
            dgv.DefaultCellStyle.SelectionForeColor = ColorBlanco;
            dgv.GridColor = Color.LightGray;

            // Aquí sí forzamos FILL porque pediste que se viera completa, 
            // pero si prefieres que no, borra la siguiente línea:
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private static void ConfigurarPanel(Panel pnl)
        {
            if (pnl.Name.Contains("Contenedor")) pnl.BackColor = ColorBlanco;
            else pnl.BackColor = Color.Transparent;
        }

        private static void ConfigurarGroupBox(GroupBox gb)
        {
            gb.ForeColor = ColorPrimario;
            gb.BackColor = Color.Transparent;
        }

        private static GraphicsPath Redondear(Rectangle bounds, int radius)
        {
            int diameter = radius * 2;
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(bounds.Location, size);
            GraphicsPath path = new GraphicsPath();
            if (radius == 0) { path.AddRectangle(bounds); return path; }
            path.AddArc(arc, 180, 90);
            arc.X = bounds.Right - diameter;
            path.AddArc(arc, 270, 90);
            arc.Y = bounds.Bottom - diameter;
            path.AddArc(arc, 0, 90);
            arc.X = bounds.Left;
            path.AddArc(arc, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}