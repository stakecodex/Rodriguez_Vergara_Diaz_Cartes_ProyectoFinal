﻿namespace LENTE_2
{
    partial class FormClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtRut = new TextBox();
            txtNombre = new TextBox();
            txtTelefono = new TextBox();
            txtEmail = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            cmbRegion = new ComboBox();
            label7 = new Label();
            btnGuardar = new Button();
            label8 = new Label();
            cmbComuna = new ComboBox();
            label9 = new Label();
            txtDireccion = new TextBox();
            btnlimpiar = new Button();
            btncancelar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(63, 2);
            label1.Name = "label1";
            label1.Size = new Size(674, 62);
            label1.TabIndex = 1;
            label1.Text = "Sistema de Gestión de Ópticas";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // label2
            // 
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 80);
            label2.Name = "label2";
            label2.Size = new Size(776, 480);
            label2.TabIndex = 2;
            label2.Text = "Registrar Clientes";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtRut
            // 
            txtRut.Location = new Point(152, 135);
            txtRut.Name = "txtRut";
            txtRut.Size = new Size(164, 27);
            txtRut.TabIndex = 3;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(404, 135);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(304, 27);
            txtNombre.TabIndex = 4;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(152, 168);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(164, 27);
            txtTelefono.TabIndex = 5;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(404, 169);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(304, 27);
            txtEmail.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(104, 138);
            label3.Name = "label3";
            label3.Size = new Size(42, 20);
            label3.TabIndex = 8;
            label3.Text = "RUN:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(331, 138);
            label4.Name = "label4";
            label4.Size = new Size(67, 20);
            label4.TabIndex = 9;
            label4.Text = "Nombre:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(79, 169);
            label5.Name = "label5";
            label5.Size = new Size(70, 20);
            label5.TabIndex = 10;
            label5.Text = "Telefono:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(349, 169);
            label6.Name = "label6";
            label6.Size = new Size(49, 20);
            label6.TabIndex = 11;
            label6.Text = "Email:";
            // 
            // cmbRegion
            // 
            cmbRegion.FormattingEnabled = true;
            cmbRegion.Location = new Point(152, 201);
            cmbRegion.Name = "cmbRegion";
            cmbRegion.Size = new Size(164, 28);
            cmbRegion.TabIndex = 12;
            cmbRegion.SelectedIndexChanged += cmbRegion_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(90, 201);
            label7.Name = "label7";
            label7.Size = new Size(59, 20);
            label7.TabIndex = 13;
            label7.Text = "Region:";
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(152, 304);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(162, 29);
            btnGuardar.TabIndex = 14;
            btnGuardar.Text = "Guardar Cliente";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click_1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(339, 201);
            label8.Name = "label8";
            label8.Size = new Size(67, 20);
            label8.TabIndex = 15;
            label8.Text = "Comuna:";
            // 
            // cmbComuna
            // 
            cmbComuna.FormattingEnabled = true;
            cmbComuna.Location = new Point(404, 201);
            cmbComuna.Name = "cmbComuna";
            cmbComuna.Size = new Size(304, 28);
            cmbComuna.TabIndex = 16;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.ButtonHighlight;
            label9.Location = new Point(74, 235);
            label9.Name = "label9";
            label9.Size = new Size(75, 20);
            label9.TabIndex = 17;
            label9.Text = "Direccion:";
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(152, 235);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new Size(556, 27);
            txtDireccion.TabIndex = 18;
            txtDireccion.TextChanged += txtDireccion_TextChanged;
            // 
            // btnlimpiar
            // 
            btnlimpiar.Location = new Point(331, 304);
            btnlimpiar.Name = "btnlimpiar";
            btnlimpiar.Size = new Size(162, 29);
            btnlimpiar.TabIndex = 19;
            btnlimpiar.Text = "Limpiar";
            btnlimpiar.UseVisualStyleBackColor = true;
            // 
            // btncancelar
            // 
            btncancelar.Location = new Point(509, 304);
            btncancelar.Name = "btncancelar";
            btncancelar.Size = new Size(162, 29);
            btncancelar.TabIndex = 20;
            btncancelar.Text = "Cancelar";
            btncancelar.UseVisualStyleBackColor = true;
            btncancelar.Click += btncancelar_Click;
            // 
            // FormClientes
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 571);
            Controls.Add(btncancelar);
            Controls.Add(btnlimpiar);
            Controls.Add(txtDireccion);
            Controls.Add(label9);
            Controls.Add(cmbComuna);
            Controls.Add(label8);
            Controls.Add(btnGuardar);
            Controls.Add(label7);
            Controls.Add(cmbRegion);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txtEmail);
            Controls.Add(txtTelefono);
            Controls.Add(txtNombre);
            Controls.Add(txtRut);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormClientes";
            Text = "FormClientes";
            Load += FormClientes_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtRut;
        private TextBox txtNombre;
        private TextBox txtTelefono;
        private TextBox txtEmail;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private ComboBox cmbRegion;
        private Label label7;
        private Button btnGuardar;
        private Label label8;
        private ComboBox cmbComuna;
        private Label label9;
        private TextBox txtDireccion;
        private Button btnlimpiar;
        private Button btncancelar;
    }
}