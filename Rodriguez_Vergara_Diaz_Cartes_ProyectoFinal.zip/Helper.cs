﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LENTE_2
{
    public static class GestorArchivos
    {
        public static void Guardar(string nombreArchivo, string linea)
        {
            using (StreamWriter writer = new StreamWriter(nombreArchivo, true))
            {
                writer.WriteLine(linea);
            }
        }

        public static List<string> Leer(string nombreArchivo)
        {
            List<string> lineas = new List<string>();
            if (File.Exists(nombreArchivo))
            {
                using (StreamReader reader = new StreamReader(nombreArchivo))
                {
                    string linea;
                    while ((linea = reader.ReadLine()) != null)
                    {
                        lineas.Add(linea);
                    }
                }
            }
            return lineas;
        }
    }
}
