﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions; // Necesario para validar el formato de Email y Teléfono

namespace LENTE_2
{
    public partial class FormClientes : Form
    {
        string archivo = "clientes.txt";

        public FormClientes()
        {
            InitializeComponent();

            // ═══════════════════════════════════════════════════════════
            // ASIGNACIÓN DE REGLAS DE ESCRITURA (EN TIEMPO REAL)
            // ═══════════════════════════════════════════════════════════

            // 1. RUT: Solo números y K, y formato automático
            txtRut.KeyPress += ValidarTeclaRUT;
            txtRut.TextChanged += FormatearRutAutomatico;

            // 2. NOMBRE: Solo letras (bloquea números)
            txtNombre.KeyPress += ValidarSoloLetras;

            // 3. TELÉFONO: Solo números y '+'
            txtTelefono.KeyPress += ValidarSoloNumeros;

            // 4. DIRECCIÓN: Sin restricciones (permite todo)

            // 5. EMAIL: Sin restricción de teclado, se valida al guardar
        }

        private void FormClientes_Load(object sender, EventArgs e)
        {
            Estilos.Aplicar(this);
            CargarRegiones();
        }

        // ═══════════════════════════════════════════════════════════
        // EVENTOS DE CONTROL DE TECLADO (FILTROS)
        // ═══════════════════════════════════════════════════════════

        // Solo permite Letras, Espacio y Borrar
        private void ValidarSoloLetras(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Bloquea la tecla
            }
        }

        // Solo permite Números, Símbolo '+' y Borrar
        private void ValidarSoloNumeros(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != '+')
            {
                e.Handled = true;
            }
        }

        // Solo permite Números y K (para el RUT)
        private void ValidarTeclaRUT(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != 'k' && e.KeyChar != 'K')
            {
                e.Handled = true;
            }
        }

        // Agrega el guion automáticamente antes del último dígito
        private void FormatearRutAutomatico(object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            // Quitamos guiones y puntos existentes para trabajar con el dato limpio
            string texto = txt.Text.Replace("-", "").Replace(".", "");

            if (texto.Length > 1)
            {
                // Separamos el cuerpo del dígito verificador
                string cuerpo = texto.Substring(0, texto.Length - 1);
                string dv = texto.Substring(texto.Length - 1, 1);

                txt.TextChanged -= FormatearRutAutomatico; // Pausamos evento para no crear bucle infinito
                txt.Text = cuerpo + "-" + dv; // Armamos el RUT
                txt.SelectionStart = txt.Text.Length; // Ponemos el cursor al final
                txt.TextChanged += FormatearRutAutomatico; // Reactivamos evento
            }
        }

        // ═══════════════════════════════════════════════════════════
        // BOTONES DE ACCIÓN
        // ═══════════════════════════════════════════════════════════

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            try
            {
                // VALIDACIÓN 1: Campos Vacíos
                if (string.IsNullOrWhiteSpace(txtRut.Text) || string.IsNullOrWhiteSpace(txtNombre.Text) ||
                    string.IsNullOrWhiteSpace(txtTelefono.Text) || string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("⚠️ Todos los campos son obligatorios (excepto Dirección).", "Faltan Datos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // VALIDACIÓN 2: RUT Matemáticamente Válido
                if (!ValidarRutChileno(txtRut.Text))
                {
                    MessageBox.Show("❌ El RUT ingresado no es válido.\nPor favor revise el dígito verificador.", "RUT Incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // VALIDACIÓN 3: Formato de Correo
                if (!Regex.IsMatch(txtEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    MessageBox.Show("❌ El correo electrónico no es válido.", "Email Incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // VALIDACIÓN 4: Duplicados
                if (File.Exists(archivo))
                {
                    List<string> lineas = GestorArchivos.Leer(archivo);
                    foreach (string linea in lineas)
                    {
                        string[] datos = linea.Split('|');
                        // Comparamos RUT limpio
                        if (datos.Length > 1 && datos[1].Replace(".", "").Replace("-", "").ToUpper() == txtRut.Text.Replace(".", "").Replace("-", "").ToUpper())
                        {
                            MessageBox.Show("⚠️ Este cliente ya está registrado en el sistema.", "Duplicado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                }

                // --- GUARDADO ---

                // Generar ID Consecutivo
                int id = 1;
                if (File.Exists(archivo))
                {
                    List<string> lineas = GestorArchivos.Leer(archivo);
                    if (lineas.Count > 0)
                    {
                        try { id = lineas.Select(l => int.Parse(l.Split('|')[0])).Max() + 1; }
                        catch { id = lineas.Count + 1; }
                    }
                }

                // Crear Objeto Cliente (Limpiando caracteres peligrosos como '|')
                GestionClientes nuevoCliente = new GestionClientes(
                    id,
                    txtRut.Text.ToUpper(),
                    txtNombre.Text.Replace("|", ""),
                    cmbRegion.Text,
                    cmbComuna.Text,
                    txtDireccion.Text.Replace("|", ""),
                    txtTelefono.Text.Replace("|", ""),
                    txtEmail.Text.Replace("|", "")
                );

                GestorArchivos.Guardar(archivo, nuevoCliente.ATexto());

                MessageBox.Show($"✅ Cliente registrado con éxito.\nID Asignado: {id}", "Registro Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Preguntar si quiere ir a vender
                DialogResult respuesta = MessageBox.Show(
                    "¿Desea realizar una VENTA para este cliente ahora mismo?",
                    "Continuar",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (respuesta == DialogResult.Yes)
                {
                    this.Hide();
                    FormVentas ventanaVenta = new FormVentas(txtRut.Text);
                    ventanaVenta.ShowDialog();
                    this.Close();
                }
                else
                {
                    LimpiarCampos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error crítico al guardar: " + ex.Message);
            }
        }

        // BOTÓN CANCELAR (Solicitado)
        private void btncancelar_Click(object sender, EventArgs e)
        {
            // Si el usuario escribió algo, preguntamos antes de borrar
            if (!string.IsNullOrEmpty(txtRut.Text) || !string.IsNullOrEmpty(txtNombre.Text))
            {
                DialogResult r = MessageBox.Show("¿Está seguro de cancelar el registro?\nSe perderán los datos ingresados.",
                                                 "Cancelar Registro", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (r == DialogResult.No) return; // Si dice NO, no hacemos nada
            }

            // Si dice SÍ (o estaba vacío), limpiamos y cerramos
            LimpiarCampos();
            this.Close();
        }

        // Botón Limpiar (Opcional, si lo tienes en el diseño)
        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        // ═══════════════════════════════════════════════════════════
        // MÉTODOS AUXILIARES
        // ═══════════════════════════════════════════════════════════

        private void LimpiarCampos()
        {
            txtRut.Clear();
            txtNombre.Clear();
            cmbComuna.Text = "";
            if (cmbComuna.Items.Count > 0) cmbComuna.SelectedIndex = -1;
            txtDireccion.Clear();
            txtTelefono.Clear();
            txtEmail.Clear();
        }

        // Algoritmo Matemático para validar RUT Chileno
        private bool ValidarRutChileno(string rut)
        {
            try
            {
                rut = rut.Replace(".", "").Replace("-", "").ToUpper();
                if (rut.Length < 2) return false;

                string rutAux = rut.Substring(0, rut.Length - 1);
                char dv = char.Parse(rut.Substring(rut.Length - 1, 1));

                int m = 0, s = 1;
                for (; !string.IsNullOrEmpty(rutAux); rutAux = rutAux.Substring(0, rutAux.Length - 1))
                {
                    s = (s + int.Parse(rutAux.Substring(rutAux.Length - 1, 1)) * (9 - m++ % 6)) % 11;
                }
                char dvEsperado = (char)(s != 0 ? s + 47 : 75);

                return dv == dvEsperado;
            }
            catch { return false; }
        }

        private void CargarRegiones()
        {
            cmbRegion.Items.Clear();
            cmbRegion.Items.AddRange(new string[] {
                "Arica y Parinacota", "Tarapacá", "Antofagasta", "Atacama", "Coquimbo",
                "Valparaíso", "Región Metropolitana", "O'Higgins", "Maule", "Ñuble",
                "Biobío", "Araucanía", "Los Ríos", "Los Lagos", "Aysén", "Magallanes"
            });
            cmbRegion.SelectedIndex = 0;
        }

        private void cmbRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            string regionSeleccionada = cmbRegion.Text;
            cmbComuna.Items.Clear();
            cmbComuna.Text = "";

            switch (regionSeleccionada)
            {
                case "Arica y Parinacota": cmbComuna.Items.AddRange(new string[] { "Arica", "Camarones", "Putre", "General Lagos" }); break;
                case "Tarapacá": cmbComuna.Items.AddRange(new string[] { "Iquique", "Alto Hospicio", "Pozo Almonte", "Pica", "Huara" }); break;
                case "Antofagasta": cmbComuna.Items.AddRange(new string[] { "Antofagasta", "Mejillones", "Taltal", "Calama", "San Pedro de Atacama" }); break;
                case "Atacama": cmbComuna.Items.AddRange(new string[] { "Copiapó", "Caldera", "Vallenar", "Huasco", "Chañaral" }); break;
                case "Coquimbo": cmbComuna.Items.AddRange(new string[] { "La Serena", "Coquimbo", "Andacollo", "Ovalle", "Illapel", "Los Vilos", "Salamanca" }); break;
                case "Valparaíso": cmbComuna.Items.AddRange(new string[] { "Valparaíso", "Viña del Mar", "Concón", "Quilpué", "Villa Alemana", "San Antonio", "Quillota", "Los Andes", "San Felipe" }); break;
                case "Región Metropolitana": cmbComuna.Items.AddRange(new string[] { "Santiago", "Providencia", "Las Condes", "Ñuñoa", "La Florida", "Maipú", "Puente Alto", "San Bernardo", "Quilicura", "Pudahuel", "Peñalolén", "Estación Central" }); break;
                case "O'Higgins": cmbComuna.Items.AddRange(new string[] { "Rancagua", "Machalí", "Rengo", "San Fernando", "Santa Cruz", "Pichilemu" }); break;
                case "Maule": cmbComuna.Items.AddRange(new string[] { "Talca", "Curicó", "Linares", "Constitución", "Cauquenes", "Parral" }); break;
                case "Ñuble": cmbComuna.Items.AddRange(new string[] { "Chillán", "Chillán Viejo", "San Carlos", "Bulnes", "Yungay", "Quillón" }); break;
                case "Biobío": cmbComuna.Items.AddRange(new string[] { "Concepción", "Talcahuano", "San Pedro de la Paz", "Chiguayante", "Los Ángeles", "Coronel", "Lota", "Tomé" }); break;
                case "Araucanía": cmbComuna.Items.AddRange(new string[] { "Temuco", "Padre Las Casas", "Villarrica", "Pucón", "Angol", "Victoria" }); break;
                case "Los Ríos": cmbComuna.Items.AddRange(new string[] { "Valdivia", "Corral", "La Unión", "Río Bueno", "Panguipulli" }); break;
                case "Los Lagos": cmbComuna.Items.AddRange(new string[] { "Puerto Montt", "Puerto Varas", "Osorno", "Castro", "Ancud", "Frutillar" }); break;
                case "Aysén": cmbComuna.Items.AddRange(new string[] { "Coyhaique", "Aysén", "Chile Chico", "Cochrane" }); break;
                case "Magallanes": cmbComuna.Items.AddRange(new string[] { "Punta Arenas", "Puerto Natales", "Porvenir", "Cabo de Hornos" }); break;
            }
        }

        private void txtDireccion_TextChanged(object sender, EventArgs e) { }
    }
}