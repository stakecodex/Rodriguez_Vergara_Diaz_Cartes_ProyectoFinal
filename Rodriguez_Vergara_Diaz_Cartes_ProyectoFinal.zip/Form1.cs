namespace LENTE_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Estilos.Aplicar(this);
        }

        private void btncotizarreceta_Click(object sender, EventArgs e)
        {

        }

        private void btncotizarreceta_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            FormCotizar ventana = new FormCotizar();
            ventana.ShowDialog();
            this.Show();

        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormClientes ventana = new FormClientes();
            ventana.ShowDialog();
            this.Show();

        }

        private void btnVentas_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormVentas ventana = new FormVentas();
            ventana.ShowDialog();
            this.Show();
        }

        private void btnInventario_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormInventario ventana = new FormInventario();
            ventana.ShowDialog();
            this.Show();
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnVerLista_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormListaClientes ventana = new FormListaClientes();
            ventana.ShowDialog();
            this.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
