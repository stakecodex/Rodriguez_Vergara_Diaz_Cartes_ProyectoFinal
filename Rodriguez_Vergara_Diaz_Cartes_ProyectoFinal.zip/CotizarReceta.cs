﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LENTE_2
{
    internal class CotizarReceta
    {
        public int Id { get; set; }
        public decimal Esfera { get; set; }
        public decimal Cilindro { get; set; }
        public bool EsMultifocal { get; set; }
        public int RangoCalculado { get; private set; } // 1, 2 o 3 según PDF

        public CotizarReceta(int id, decimal esfera, decimal cilindro, bool esMultifocal)
        {
            Id = id;
            Esfera = esfera;
            Cilindro = cilindro;
            EsMultifocal = esMultifocal;
            CalcularRango(); // Calculamos el rango automáticamente al crear
        }

        // Lógica extraída de tu documento "IA para ventas"
        private void CalcularRango()
        {
            // Convertimos a positivo para comparar magnitud absoluta
            decimal esfAbs = Math.Abs(Esfera);
            decimal cilAbs = Math.Abs(Cilindro);

            if (esfAbs <= 3 && cilAbs <= 2)
            {
                RangoCalculado = 1; // Opción 1
            }
            else if ((esfAbs > 3 && esfAbs <= 6) || (cilAbs > 2 && cilAbs <= 4))
            {
                RangoCalculado = 2; // Opción 2
            }
            else
            {
                RangoCalculado = 3; // Opción 3 (O superior)
            }
        }

        public string ATexto()
        {
            return $"{Id}|{Esfera}|{Cilindro}|{EsMultifocal}|{RangoCalculado}";
        }

        public static CotizarReceta DesdeTexto(string linea)
        {
            string[] datos = linea.Split('|');
            return new CotizarReceta(
                int.Parse(datos[0]),
                decimal.Parse(datos[1]),
                decimal.Parse(datos[2]),
                bool.Parse(datos[3])
            );
        }
    }
}
