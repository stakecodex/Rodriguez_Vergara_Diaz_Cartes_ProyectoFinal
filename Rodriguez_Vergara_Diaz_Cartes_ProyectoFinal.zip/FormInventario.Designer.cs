﻿namespace LENTE_2
{
    partial class FormInventario
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            lblModelo = new Label();
            lblCategoria = new Label();
            lblPrecio = new Label();
            lblStock = new Label();
            txtModelo = new TextBox();
            txtCategoria = new TextBox();
            txtPrecio = new TextBox();
            txtStock = new TextBox();
            btnGuardar = new Button();
            btnEliminar = new Button();
            btnEditar = new Button();
            btnActualizar = new Button();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // lblModelo
            // 
            lblModelo.AutoSize = true;
            lblModelo.Location = new Point(50, 130);
            lblModelo.Name = "lblModelo";
            lblModelo.Size = new Size(61, 20);
            lblModelo.TabIndex = 2;
            lblModelo.Text = "Modelo";
            // 
            // lblCategoria
            // 
            lblCategoria.AutoSize = true;
            lblCategoria.Location = new Point(250, 130);
            lblCategoria.Name = "lblCategoria";
            lblCategoria.Size = new Size(74, 20);
            lblCategoria.TabIndex = 3;
            lblCategoria.Text = "Categoría";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(450, 130);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(50, 20);
            lblPrecio.TabIndex = 4;
            lblPrecio.Text = "Precio";
            // 
            // lblStock
            // 
            lblStock.AutoSize = true;
            lblStock.Location = new Point(650, 130);
            lblStock.Name = "lblStock";
            lblStock.Size = new Size(45, 20);
            lblStock.TabIndex = 5;
            lblStock.Text = "Stock";
            // 
            // txtModelo
            // 
            txtModelo.Location = new Point(50, 150);
            txtModelo.Name = "txtModelo";
            txtModelo.Size = new Size(180, 27);
            txtModelo.TabIndex = 6;
            // 
            // txtCategoria
            // 
            txtCategoria.Location = new Point(250, 150);
            txtCategoria.Name = "txtCategoria";
            txtCategoria.Size = new Size(180, 27);
            txtCategoria.TabIndex = 7;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(450, 150);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(180, 27);
            txtPrecio.TabIndex = 8;
            // 
            // txtStock
            // 
            txtStock.Location = new Point(650, 150);
            txtStock.Name = "txtStock";
            txtStock.Size = new Size(100, 27);
            txtStock.TabIndex = 9;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(300, 200);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(200, 40);
            btnGuardar.TabIndex = 10;
            btnGuardar.Text = "Guardar Producto";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(96, 530);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(150, 40);
            btnEliminar.TabIndex = 12;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(309, 530);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(150, 40);
            btnEditar.TabIndex = 13;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnActualizar
            // 
            btnActualizar.Location = new Point(529, 530);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(150, 40);
            btnActualizar.TabIndex = 14;
            btnActualizar.Text = "Actualizar Datos";
            btnActualizar.UseVisualStyleBackColor = true;
            btnActualizar.Click += btnActualizar_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 260);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(776, 250);
            dataGridView1.TabIndex = 11;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(76, 3);
            label1.Name = "label1";
            label1.Size = new Size(674, 62);
            label1.TabIndex = 15;
            label1.Text = "Sistema de Gestión de Ópticas";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(3, 75);
            label2.Name = "label2";
            label2.Size = new Size(793, 516);
            label2.TabIndex = 16;
            label2.Text = "Inventario";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // FormInventario
            // 
            ClientSize = new Size(800, 600);
            Controls.Add(label1);
            Controls.Add(lblModelo);
            Controls.Add(lblCategoria);
            Controls.Add(lblPrecio);
            Controls.Add(lblStock);
            Controls.Add(txtModelo);
            Controls.Add(txtCategoria);
            Controls.Add(txtPrecio);
            Controls.Add(txtStock);
            Controls.Add(btnGuardar);
            Controls.Add(dataGridView1);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditar);
            Controls.Add(btnActualizar);
            Controls.Add(label2);
            Name = "FormInventario";
            Text = "Inventario";
            Load += FormInventario_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Label lblModelo;
        private System.Windows.Forms.Label lblCategoria;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.TextBox txtCategoria;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.TextBox txtStock;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnActualizar;
        private Label label1;
        private Label label2;
    }
}