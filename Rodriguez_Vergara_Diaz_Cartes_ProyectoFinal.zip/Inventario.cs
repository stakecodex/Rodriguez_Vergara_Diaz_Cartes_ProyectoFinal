﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LENTE_2
{
    internal class Inventario
    {
        public int Id { get; set; }
        public string CodigoModelo { get; set; } // Ej: C-111
        public string Categoria { get; set; }    // Ej: Economica, Intermedia, ClipOn
        public decimal PrecioBase { get; set; }
        public int Stock { get; set; }

        public Inventario(int id, string codigo, string categoria, decimal precio, int stock)
        {
            Id = id;
            CodigoModelo = codigo;
            Categoria = categoria;
            PrecioBase = precio;
            Stock = stock;
        }

        public string ATexto()
        {
            return $"{Id}|{CodigoModelo}|{Categoria}|{PrecioBase}|{Stock}";
        }

        public static Inventario DesdeTexto(string linea)
        {
            string[] datos = linea.Split('|');
            return new Inventario(
                int.Parse(datos[0]),
                datos[1],
                datos[2],
                decimal.Parse(datos[3]),
                int.Parse(datos[4])
            );
        }
    }
}
