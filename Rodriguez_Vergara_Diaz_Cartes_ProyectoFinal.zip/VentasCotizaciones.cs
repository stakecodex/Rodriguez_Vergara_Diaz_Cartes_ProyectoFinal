﻿using System;

namespace LENTE_2
{
    public class VentasCotizaciones
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public string RutCliente { get; set; }
        public string CodigoProducto { get; set; }
        public decimal TotalPagar { get; set; }
        public string Extras { get; set; }

        public VentasCotizaciones(int id, DateTime fecha, string rutCliente, string codigoProducto, decimal total, string extras)
        {
            Id = id;
            Fecha = fecha;
            RutCliente = rutCliente;
            CodigoProducto = codigoProducto;
            TotalPagar = total;
            Extras = extras;
        }

        public string ATexto()
        {
            return $"{Id}|{Fecha}|{RutCliente}|{CodigoProducto}|{TotalPagar}|{Extras}";
        }

        public static VentasCotizaciones DesdeTexto(string linea)
        {
            string[] datos = linea.Split('|');
            return new VentasCotizaciones(
                int.Parse(datos[0]),
                DateTime.Parse(datos[1]),
                datos[2],
                datos[3],
                decimal.Parse(datos[4]),
                datos.Length > 5 ? datos[5] : ""
            );
        }
    }
}