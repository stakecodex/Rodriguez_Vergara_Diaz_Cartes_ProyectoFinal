﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace LENTE_2
{
    public partial class FormInventario : Form
    {
        string archivo = "inventario.txt";
        private string idProductoEnEdicion = null;

        public FormInventario()
        {
            InitializeComponent();
            this.Activated += FormInventario_Activated;
        }

        private void FormInventario_Load(object sender, EventArgs e)
        {
            Estilos.Aplicar(this); // <--- AGREGA ESTA LÍNEA MÁGICA
            ConfigurarGrilla();
            CargarInventario();
            ResetearModoEdicion();
        }

        private void FormInventario_Activated(object sender, EventArgs e)
        {
            CargarInventario();
        }

        private void ConfigurarGrilla()
        {
            if (dataGridView1.Columns.Count == 0)
            {
                dataGridView1.Columns.Add("Id", "ID");
                dataGridView1.Columns.Add("Modelo", "Modelo");
                dataGridView1.Columns.Add("Categoria", "Categoría");
                dataGridView1.Columns.Add("Precio", "Precio");
                dataGridView1.Columns.Add("Stock", "Stock");
            }

            dataGridView1.Columns[0].Visible = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
        }

        private void CargarInventario()
        {
            dataGridView1.Rows.Clear();
            if (File.Exists(archivo))
            {
                List<string> lineas = GestorArchivos.Leer(archivo);
                foreach (string linea in lineas)
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(linea)) continue;
                        Inventario prod = Inventario.DesdeTexto(linea);
                        dataGridView1.Rows.Add(prod.Id, prod.CodigoModelo, prod.Categoria, prod.PrecioBase, prod.Stock);
                    }
                    catch { continue; }
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (idProductoEnEdicion != null)
            {
                DialogResult r = MessageBox.Show("Estás editando un producto. ¿Quieres cancelar la edición?", "Atención", MessageBoxButtons.YesNo);
                if (r == DialogResult.Yes) ResetearModoEdicion();
                else return;
            }

            if (e.RowIndex >= 0 && dataGridView1.SelectedRows.Count > 0)
            {
                txtModelo.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                txtCategoria.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                txtPrecio.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                txtStock.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (idProductoEnEdicion == null)
            {
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Selecciona un producto para editar.");
                    return;
                }

                idProductoEnEdicion = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                btnEditar.Text = "Confirmar Cambios";
                btnEditar.BackColor = Color.LightGreen;
                btnGuardar.Enabled = false;
                btnEliminar.Enabled = false;
                dataGridView1.Enabled = false;

                MessageBox.Show("Modo Edición Activado.");
            }
            else
            {
                GuardarEdicionEnArchivo();
            }
        }

        private void GuardarEdicionEnArchivo()
        {
            try
            {
                // Validación de Negativos
                if (!decimal.TryParse(txtPrecio.Text, out decimal pCheck)) pCheck = 0;
                if (!int.TryParse(txtStock.Text, out int sCheck)) sCheck = 0;

                if (pCheck < 0 || sCheck < 0)
                {
                    MessageBox.Show("El precio y el stock no pueden ser negativos.", "Error Lógico", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                List<string> lineas = GestorArchivos.Leer(archivo);
                List<string> nuevasLineas = new List<string>();
                bool encontrado = false;

                foreach (string linea in lineas)
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(linea)) continue;
                        Inventario prod = Inventario.DesdeTexto(linea);

                        if (prod.Id.ToString() == idProductoEnEdicion)
                        {
                            prod.CodigoModelo = txtModelo.Text.Replace("|", "");
                            prod.Categoria = txtCategoria.Text.Replace("|", "");
                            prod.PrecioBase = pCheck;
                            prod.Stock = sCheck;
                            encontrado = true;
                        }
                        nuevasLineas.Add(prod.ATexto());
                    }
                    catch { continue; }
                }

                if (encontrado)
                {
                    File.WriteAllLines(archivo, nuevasLineas);
                    MessageBox.Show("¡Cambios guardados exitosamente!");
                    CargarInventario();
                    ResetearModoEdicion();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al editar: " + ex.Message);
            }
        }

        private void ResetearModoEdicion()
        {
            idProductoEnEdicion = null;
            btnEditar.Text = "Editar";
            btnEditar.BackColor = SystemColors.Control;
            btnGuardar.Enabled = true;
            btnEliminar.Enabled = true;
            dataGridView1.Enabled = true;
            LimpiarCampos();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtModelo.Text) || string.IsNullOrWhiteSpace(txtPrecio.Text))
                {
                    MessageBox.Show("Ingresa Modelo y Precio.");
                    return;
                }

                if (!decimal.TryParse(txtPrecio.Text, out decimal precio)) precio = 0;
                if (!int.TryParse(txtStock.Text, out int stock)) stock = 0;

                // Validación de Negativos
                if (precio < 0 || stock < 0)
                {
                    MessageBox.Show("El precio y el stock no pueden ser negativos.", "Error Lógico", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int idNuevo = 1;
                List<string> lineas = GestorArchivos.Leer(archivo);

                if (lineas.Count > 0)
                {
                    try
                    {
                        var ids = new List<int>();
                        foreach (var l in lineas)
                        {
                            try { ids.Add(int.Parse(l.Split('|')[0])); } catch { }
                        }
                        if (ids.Count > 0) idNuevo = ids.Max() + 1;
                    }
                    catch { idNuevo = lineas.Count + 1; }
                }

                string modelo = txtModelo.Text.Replace("|", "");
                string categoria = txtCategoria.Text.Replace("|", "");

                Inventario nuevo = new Inventario(idNuevo, modelo, categoria, precio, stock);
                GestorArchivos.Guardar(archivo, nuevo.ATexto());

                MessageBox.Show($"Nuevo producto creado. ID: {idNuevo}");
                LimpiarCampos();
                CargarInventario();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un producto para eliminar.");
                return;
            }

            string nombre = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            string idBorrar = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

            if (MessageBox.Show($"¿Eliminar '{nombre}'?", "Confirmar", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                List<string> lineas = GestorArchivos.Leer(archivo);
                List<string> nuevasLineas = new List<string>();

                foreach (string linea in lineas)
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(linea)) continue;
                        Inventario prod = Inventario.DesdeTexto(linea);
                        if (prod.Id.ToString() != idBorrar) nuevasLineas.Add(linea);
                    }
                    catch { continue; }
                }

                File.WriteAllLines(archivo, nuevasLineas);
                MessageBox.Show("Eliminado.");
                LimpiarCampos();
                CargarInventario();
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            CargarInventario();
            ResetearModoEdicion();
        }

        private void LimpiarCampos()
        {
            txtModelo.Clear();
            txtCategoria.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}