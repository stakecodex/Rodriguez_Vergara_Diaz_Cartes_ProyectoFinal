﻿namespace LENTE_2
{
    partial class FormVentas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            cmbClientes = new ComboBox();
            cmbProductos = new ComboBox();
            chkAzul = new CheckBox();
            chkFoto = new CheckBox();
            chkPoli = new CheckBox();
            label3 = new Label();
            label4 = new Label();
            lblTotal = new Label();
            btnVenta = new Button();
            dataGridView1 = new DataGridView();
            chkAntiReflejo = new CheckBox();
            label2 = new Label();
            label5 = new Label();
            cmbadelgazado = new ComboBox();
            chkTenido = new CheckBox();
            btnEliminar = new Button();
            btnLimpiar = new Button();
            btneditarcliente = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(62, 1);
            label1.Name = "label1";
            label1.Size = new Size(674, 62);
            label1.TabIndex = 1;
            label1.Text = "Sistema de Gestión de Ópticas";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // cmbClientes
            // 
            cmbClientes.FormattingEnabled = true;
            cmbClientes.Location = new Point(29, 140);
            cmbClientes.Name = "cmbClientes";
            cmbClientes.Size = new Size(227, 28);
            cmbClientes.TabIndex = 4;
            // 
            // cmbProductos
            // 
            cmbProductos.FormattingEnabled = true;
            cmbProductos.Location = new Point(294, 140);
            cmbProductos.Name = "cmbProductos";
            cmbProductos.Size = new Size(219, 28);
            cmbProductos.TabIndex = 5;
            // 
            // chkAzul
            // 
            chkAzul.AutoSize = true;
            chkAzul.BackColor = SystemColors.ButtonHighlight;
            chkAzul.Location = new Point(393, 174);
            chkAzul.Name = "chkAzul";
            chkAzul.Size = new Size(155, 24);
            chkAzul.TabIndex = 6;
            chkAzul.Text = "Filtro Azul ($8.000)";
            chkAzul.UseVisualStyleBackColor = false;
            // 
            // chkFoto
            // 
            chkFoto.AutoSize = true;
            chkFoto.BackColor = SystemColors.ButtonHighlight;
            chkFoto.Location = new Point(294, 199);
            chkFoto.Name = "chkFoto";
            chkFoto.Size = new Size(193, 24);
            chkFoto.TabIndex = 7;
            chkFoto.Text = "Fotocromático ($10.000)";
            chkFoto.UseVisualStyleBackColor = false;
            // 
            // chkPoli
            // 
            chkPoli.AutoSize = true;
            chkPoli.BackColor = SystemColors.ButtonHighlight;
            chkPoli.Location = new Point(199, 174);
            chkPoli.Name = "chkPoli";
            chkPoli.Size = new Size(188, 24);
            chkPoli.TabIndex = 8;
            chkPoli.Text = "Policarbonato ($10.000)";
            chkPoli.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(118, 117);
            label3.Name = "label3";
            label3.Size = new Size(58, 20);
            label3.TabIndex = 9;
            label3.Text = "Cliente:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(358, 117);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 10;
            label4.Text = "Producto:";
            // 
            // lblTotal
            // 
            lblTotal.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblTotal.Location = new Point(393, 229);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(226, 36);
            lblTotal.TabIndex = 11;
            lblTotal.Text = "$ 0";
            // 
            // btnVenta
            // 
            btnVenta.Location = new Point(172, 229);
            btnVenta.Name = "btnVenta";
            btnVenta.Size = new Size(180, 36);
            btnVenta.TabIndex = 12;
            btnVenta.Text = "Guardar Venta";
            btnVenta.UseVisualStyleBackColor = true;
            btnVenta.Click += btnVenta_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 280);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(776, 205);
            dataGridView1.TabIndex = 13;
            // 
            // chkAntiReflejo
            // 
            chkAntiReflejo.AutoSize = true;
            chkAntiReflejo.BackColor = SystemColors.ButtonHighlight;
            chkAntiReflejo.Location = new Point(29, 174);
            chkAntiReflejo.Name = "chkAntiReflejo";
            chkAntiReflejo.Size = new Size(164, 24);
            chkAntiReflejo.TabIndex = 14;
            chkAntiReflejo.Text = "Anti-reflejo ($5.000)";
            chkAntiReflejo.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 75);
            label2.Name = "label2";
            label2.Size = new Size(776, 480);
            label2.TabIndex = 3;
            label2.Text = "Ventas";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(606, 117);
            label5.Name = "label5";
            label5.Size = new Size(93, 20);
            label5.TabIndex = 15;
            label5.Text = "Adelgazado:";
            // 
            // cmbadelgazado
            // 
            cmbadelgazado.FormattingEnabled = true;
            cmbadelgazado.Location = new Point(554, 140);
            cmbadelgazado.Name = "cmbadelgazado";
            cmbadelgazado.Size = new Size(221, 28);
            cmbadelgazado.TabIndex = 16;
            // 
            // chkTenido
            // 
            chkTenido.AutoSize = true;
            chkTenido.BackColor = SystemColors.ButtonHighlight;
            chkTenido.Location = new Point(554, 174);
            chkTenido.Name = "chkTenido";
            chkTenido.Size = new Size(133, 24);
            chkTenido.TabIndex = 17;
            chkTenido.Text = "Teñido ($5.000)";
            chkTenido.UseVisualStyleBackColor = false;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(358, 491);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(94, 29);
            btnEliminar.TabIndex = 18;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(593, 491);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(94, 29);
            btnLimpiar.TabIndex = 20;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btneditarcliente
            // 
            btneditarcliente.Location = new Point(111, 491);
            btneditarcliente.Name = "btneditarcliente";
            btneditarcliente.Size = new Size(145, 29);
            btneditarcliente.TabIndex = 21;
            btneditarcliente.Text = "Editar Cliente";
            btneditarcliente.UseVisualStyleBackColor = true;
            btneditarcliente.Click += btneditarcliente_Click;
            // 
            // FormVentas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 571);
            Controls.Add(btneditarcliente);
            Controls.Add(btnLimpiar);
            Controls.Add(btnEliminar);
            Controls.Add(chkTenido);
            Controls.Add(cmbadelgazado);
            Controls.Add(label5);
            Controls.Add(chkAntiReflejo);
            Controls.Add(dataGridView1);
            Controls.Add(btnVenta);
            Controls.Add(lblTotal);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(chkPoli);
            Controls.Add(chkFoto);
            Controls.Add(chkAzul);
            Controls.Add(cmbProductos);
            Controls.Add(cmbClientes);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormVentas";
            Text = "FormVentas";
            Load += FormVentas_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbClientes;
        private System.Windows.Forms.ComboBox cmbProductos;
        private System.Windows.Forms.CheckBox chkAzul;
        private System.Windows.Forms.CheckBox chkFoto;
        private System.Windows.Forms.CheckBox chkPoli;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnVenta;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.CheckBox chkAntiReflejo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbadelgazado;
        private System.Windows.Forms.CheckBox chkTenido;
        private Button btnEliminar;
        private Button btnLimpiar;
        private Button btneditarcliente;
    }
}