﻿using System;

namespace LENTE_2
{
    public class GestionClientes
    {
        public int Id { get; set; }
        public string Rut { get; set; }
        public string Nombre { get; set; }
        public string Region { get; set; }
        public string Comuna { get; set; }
        public string Direccion { get; set; } // <--- NUEVO CAMPO
        public string Telefono { get; set; }
        public string Email { get; set; }

        // Constructor actualizado con direccion
        public GestionClientes(int id, string rut, string nombre, string region, string comuna, string direccion, string telefono, string email)
        {
            Id = id;
            Rut = rut;
            Nombre = nombre;
            Region = region;
            Comuna = comuna;
            Direccion = direccion; // Guardamos la dirección
            Telefono = telefono;
            Email = email;
        }

        public string ATexto()
        {
            // Agregamos la dirección a la línea de texto
            return $"{Id}|{Rut}|{Nombre}|{Region}|{Comuna}|{Direccion}|{Telefono}|{Email}";
        }

        public static GestionClientes DesdeTexto(string linea)
        {
            string[] datos = linea.Split('|');
            return new GestionClientes(
                int.Parse(datos[0]), // Id
                datos[1],            // Rut
                datos[2],            // Nombre
                datos[3],            // Región
                datos[4],            // Comuna
                datos[5],            // Dirección (Nuevo, posición 5)
                datos[6],            // Teléfono
                datos[7]             // Email
            );
        }
    }
}